#ifndef PAGE_H
#define PAGE_H
#include <string>
using std::string;
#include<vector>
using std::vector;
class Page { 
public:
    Page(int id, string url, double rank, vector<int> temp);
  //setters and getters
    int get_id();
    string get_url();
    double get_rank();
    vector <int> get_vector();
    int get_size();
    void set_rank(double r);
   
    
private:
  //Data members: id, url, pagerank, links , .. etc 
    int _id;
    string _url;
    double _rank;
    vector <int> outLink;
        
};  
#endif
