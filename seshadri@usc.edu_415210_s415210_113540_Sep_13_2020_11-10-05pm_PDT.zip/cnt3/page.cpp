#include "page.h"
#include <iostream>
//intialize id, url, rank, links
Page::Page(int id, string url, double rank, vector<int> temp) 
{
   _id = id;
   _url = url;
   _rank = rank;
    outLink = temp;
}

//getters
int Page::get_id()
{
    return _id;  
}

string Page::get_url()
{
    return _url;  
}

double Page::get_rank()
{
    return _rank;  
}

vector <int> Page::get_vector()
{
    return outLink;  
}

int Page::get_size()
{
    return outLink.size();
}

void Page::set_rank(double r)
{
    _rank = r;
}
