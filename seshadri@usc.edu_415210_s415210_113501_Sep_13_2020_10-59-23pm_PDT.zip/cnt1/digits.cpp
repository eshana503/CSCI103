/* Author: Eshana Seshadri
 * Program: digits
 * Description: Take the single decimal value and find the 1's, 10's digit, and 100's digit (in that order) and store in 3 separate variables.
 */
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int num;
    int tens;
    int hundreds;
    int ones;
    cout << "Enter an integer between 0 and 999: " << endl;
    cin >> num;
    
    hundreds = num/100;
    tens = (num%100)/10;
    ones = (num%100)%10;
    
    
    cout << "1's digit is " << ones << endl;
    cout << "10's digit is " << tens << endl;
    cout << "100's digit is " << hundreds << endl;
 
    return 0;
}
    