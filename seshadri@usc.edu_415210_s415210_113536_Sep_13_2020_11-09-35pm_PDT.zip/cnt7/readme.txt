CSCI 103 Programming Assignment 4, A Mazeing BFS

Name: Eshana Seshadri

Email Address: seshadri@usc.edu

NOTE: You can delete the questions, we only need your responses.

NOTE: It is helpful if you write at most 80 characters per line,
and avoid including special characters, so we can read your responses.

Please summarize the help you found useful for this assignment, which
may include office hours, discussion with peers, tutors, et cetera.
Saying "a CP on Tuesday" is ok if you don't remember their name.
If none, say "none".

:
=============================== Prelab ==================================

1. What data structure will you use to remember which cells have
already been added to the queue or not?

:

2. At what step of the BFS algorithm do you have to mark a cell as visited?

:

=============================== Review ==================================

1. Describe your "mymaze.txt" test file. It should have multiple paths
of different distances. When you ran your program on it, did your program 
behave as expected?

: Yes. The text file encossed multiple paths to the final destination (from start 'S' to finish 'F').
The program, once run, would find the shortest path from start to finish and allow the user to find 
errors when running the actual program.

============================== Remarks ==================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

:

Were there any specific problems you encountered? This is especially 
useful to know if you turned it in incomplete.

:

Do you have any other remarks?

:

