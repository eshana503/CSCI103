CSCI 103 Image Filtering Programming Assignment 

Name: Eshana Seshadri

Email Address: seshadri@usc.edu

Answer the questions posed in the writeup below.

NOTE: It is helpful if you write at most 80 characters per line,
and avoid including special characters, so we can read your responses.

Please summarize the help you found useful for this assignment, which
may include office hours, discussion with peers, tutors, et cetera.
Saying "a CP on Tuesday" is ok if you don't remember their name.
If none, say "none".

:

================================ Questions ==================================

1. Padding design: If we restrict the size of the Gaussian kernels to odd 
integers between 3 and 11 inclusive, and we only allow 256x256 pixel images, 
what is the size of the largest padded image needed to handle padding with 
any kernel size? At what index will the upper-left pixel of the original 
image be placed in the padded image (answer in terms of N, the kernel size)? 
At what index in the padded array will the lower-right pixel of the original 
image be placed?

: The size of the largest padded image is kernel size 11, with a padding of 11/2 = 5 pixels on both ends. This is required with dimensions 266*266. The upper-left pixel of the original image will be placed at [N/2][N/2]. The lower right pizel will be at [265-(N/2)] by [265-N/2)].

2. Kernel Design: Manually compute the raw and normalized Gaussian kernels 
for N=3, sigma=2. Use 4 decimal places. Discuss what would happen to the 
image if we used the raw kernel values.

:
  Raw Gaussian Kernels
  0.7788  0.8825  0.7788
  0.8825  1.0000  0.8825
  0.7788  0.8825  0.7788

  Normalized Gaussian Kernels
  0.1019  0.1154  0.1019
  0.1154  0.1308  0.1154
  0.1019  0.1154  0.1019

By using the raw kernel values, the image would be much brighter than the original image.

3. Experimenation:  Provide the results for ALL experiments listed in the
                    writeup.

:
    a. Sobel Operator: Edge detection by using a fixed sized kernel by making them white and everything else darker (set at 0). Edges are the boundaries between kernels.

    b. Gaussian Blur: Used for low-pass filtering by increasing N and sigma to make the image blurrier. Keeping either N or sigma constant while increasing the other one will also make the image blurrier. 

    c. Unsharp Mask: Used to sharpen an image, however the original image will not return as the unsharp mask calls a gaussian function. Therefore, the image cannot be called the same way back twice, as well as the edges will be blurred and therefore not restored.

4. Express in mathematical terms how the number of calculations your 
 program performs grows with the size, N, of the kernel.

: The number of calculations the program perfors grows by a factor of N^2 for every N kernel. The kernel matrix is a 2D array and N is the number of elements in one dimension.


================================ Remarks ====================================

Filling in anything here is OPTIONAL.

Approximately how long did you spend on this assignment?

:

Were there any specific problems you encountered? This is especially useful to
know if you turned it in incomplete.

:

Do you have any other remarks?

:
