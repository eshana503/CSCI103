#include <iostream>
#include <cmath>
#include "bmplib.h"

using namespace std;

// global variable. bad style but ok for this lab
unsigned char image[SIZE][SIZE];

// Fill in this function:
void draw_rectangle(int top, int left, int height, int width) {
    for(int i=0; i<width; i++)
    {
        if((i+left)>=0 && (i+left)<=255)
        {
            if((top)>=0 && (top)<=255)
            {
                image[top][i+left] = 0; 
            }
            if((top+height) >= 0 && (top + height) <=255)
            {
                image[top + height][i+left] = 0;
            } 
        }
    }
    for(int i=0; i<height; i++)
    {
        if((i+top)>=0 && (i+top) <= 255)
        {
            if((left) >= 0 && left <= 255)
            {
                image[i+top][left] = 0;
            }
            if((width + left) >= 0 && (width + left) <= 255)
            {
                image[i+top][left+width] = 0;
            }
        }
    }
}

// Fill in this function:
void draw_ellipse(int cy, int cx, int height, int width) {
    
    for(double theta= 0.0; theta <2*M_PI; theta += .01)
    {
        double x = (width/2)*cos(theta);
        double y = (height/2)*sin(theta);
        
        x+= cx + (width/2);
        y+= cy +(height/2);
        if(y>=0 && y<=255 && x <= 255 && x>=0)
        {
            image[(int)y][(int)x] = 0;
        }
    }

}


int main() {
   // initialize the image to all white pixels
   for (int i=0; i < SIZE; i++) {
      for (int j=0; j < SIZE; j++) {
         image[i][j] = 255;
      }
   }
   
   // Main program loop here
    int height;
    int width;
    int cx;
    int cy;
    int num;
    
    cout << "Please enter 0 for a rectangle, 1 for an ellipse, and 2 to quit";
    cout << endl;
    cin >> num;
    while(num != 2 && num <3)
    {
        if (num==0)
        {
            cout << "enter the top cx: " << endl;
            cin >> cx;
            cout << "enter the cy: " << endl;
            cin >> cy;
            cout << "enter the height: " << endl;
            cin >> height;
            cout << "enter the width: " << endl;
            cin >> width;
            
            draw_rectangle(cx, cy, height, width);
        }
        else if (num==1)
        {
            cout << "enter the top cx: " << endl;
            cin >> cx;
            cout << "enter the cy: " << endl;
            cin >> cy;
            cout << "enter the height: " << endl;
            cin >> height;
            cout << "enter the width: " << endl;
            cin >> width;
            
            draw_ellipse(cx, cy, height, width);
        }
        cout << "Please enter 0 for a rectangle, 1 for an ellipse and 2 to save your drawing as";
        cout << "output.bmp and quit, enter: 2" << endl;
        
        cin >> num;
    }
   
   // Write the resulting image to the .bmp file
   writeGSBMP("output.bmp", image);
   
   return 0;
}
