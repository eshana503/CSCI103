CSCI 103 Programming Assignment 4, Pagerank , Fall 2018

Name: <Your name here>

Email Address: <username>@usc.edu

NOTE: You can delete the questions, we only need your responses.

=============================== Prelab =======================================
Calcuate the pagerank of the pages in the graph you generated.
PR(id=0) = 2/7
PR(id=1) = 2/7
PR(id=2) = 1/7
PR(id=3) = 2/7

P(0) = P(1)
P(1) = P(3)
P(2) = P(0)/2
P(3) = P(2) + P(0)/2
    
P(0) + P(0) + P(0) + P(2) = 1
P(2) = P(0)/2
P(0) + P(0) + P(0) + P(0)/2 = 1
P(0) = 2/7
P(2) = 1/7
