/* Author: Eshana Seshadri
 * Program: ASCII Art
 * Description: Write a program to print out the *'s to form an isosceles right triangle 31 rows high.
 
 */
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main()
    
{
    int degrees;
    int x;
    int temp;
    double xRad;
    cin >> degrees;
    xRad = degrees * (M_PI/180);
    x = (tan(xRad)*31);

    
    for(int i=0; i<31; i++)
    {
        if((i*((double)x/31))>=20 && i*((double)x/31) <=30)
        {
            temp = 20;
        }
        else
        {
            temp = i*((double)x/31);
        }
        for(int j=0; j<=(temp); j++)
        {
            cout << "*";
        }
            cout << endl;
    }
    return 0;
}
        