#include "draw.h"

class Turtle
{
    public:
    
    // P.1
        Turtle(double x0, double y0, double dir0); // constructor
        void move(double dist); // member functions
        void turn(double deg);
        
    // P.2
        void setColor(Color c);
        void off();
        void on();

    private:
        double x;
        double y;
        double direction;
        Color color;
        bool drawing;        
};