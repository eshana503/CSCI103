#include "turtle.h"
#include <iostream> 
#include <cmath>

using namespace std;


Turtle::Turtle(double x0, double y0, double dir0)
{
    // initialize all of the new data members
    x = x0;
    y = y0;
    direction = dir0;
    color = draw::BLACK;
    drawing = true;
    
}

void Turtle::move(double dist)
{
    if(drawing)
    {
        draw::setcolor(color);
        draw::line(x, y, x + (dist*cos(direction*(M_PI/180))),
                   y + (dist*sin(direction*(M_PI/180))));
    }
    
    x = x + (dist*cos(direction*(M_PI/180)));
    y = y + (dist*sin(direction*(M_PI/180)));
    
}

void Turtle::turn(double deg)
{
    direction = direction + deg;    
}

void Turtle::setColor(Color c)
{
    color = c;   
}

void Turtle::off()
{
    drawing = false;
    
}

void Turtle::on()
{
   drawing = true; 
}


