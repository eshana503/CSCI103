/* Author: Eshana Seshadri
 * Program: diceplot
 * Description: Write a program to simulate 500 rolls of 4-dice
 */
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

 int getRandomNumber()
    {
        return  (rand()%6) + 1;     
    }
    
    void printHistogram(int counts[])
    {
        for(int i=0; i<21; i++)
        {
            cout << i+4;
            for(int j=0; j<counts[i] ; j++)
            {
                cout << "X";  
            }
            cout << endl;
        }
    }

int main()
{
    srand(time(0));
    int testCounts[21];
    int n;
    
    cin >> n;
    
    for(int i=0; i<21; i++)
    {
        testCounts[i] = 0;
    }
    
    for(int i=0; i<n; i++)
    {
        int sum = 0;
        for(int j=0; j<4; j++)
        {
            sum += getRandomNumber();
        }
        testCounts[sum-4]++;
    }
    
    printHistogram(testCounts);
    
  return 0;  
}

    
    
    
    
        
        
        
            
        