/* Author: Eshana Seshadri
 * Program: color_conv
 * Description: Converts RGB -> CMYK color representation
 */
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
   // Enter your code here
    double red;
    double green;
    double blue;
    
    cin >> red >> green >> blue;
    double white = max((red/255.0), (max((green/255.0),(blue/255.0)))); 
    double cyan = ((white - double(red/255))/double(white));
    double magenta = (white - double(green/255))/double(white);
    double yellow = (white - double(blue/255))/double(white);
    double black = 1 - double(white);
    
    cout << cyan << endl;
    cout << magenta << endl;
    cout << yellow << endl;
    cout << black << endl;
   
   return 0;
}
