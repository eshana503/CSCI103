#include <iostream>
#include "delist.h"
#include <stdlib.h>

using namespace std;


// Constructs an empty Double-Ended List
DEList::DEList()
{
    head = NULL;
    tail = NULL;
    _size = 0;
}

// Destructor to clean-up memory of current list
DEList::~DEList()
{
    while(!empty())
    {
        pop_front();
    }    
}
// returns a Boolean 'true' if the list is empty
bool DEList:: empty()
{
    return !size();       
}
// returns number of items in the list
int DEList:: size()
{
    return _size;    
}

// returns front item or -1 if empty list
int DEList:: front()
{
    if(empty())
    {
        return -1;
    }
    else
    {
        return head->val;
    }
}
// returns back item or -1 if empty list
int DEList:: back()
{
    if(empty())
    {
        return -1;
    }
    else
    {
        return tail->val;
    }    
}
    
// Adds a new integer to the front of the list
// Q : why so many news ? even after we have set head and tail to new DEItem?
void DEList:: push_front(int new_val)
{
    DEItem* temp = new DEItem;
    temp->val = new_val;
    temp->prev = NULL;
    temp->next = head;
    
    if(empty())
    {
        head = temp;
        tail = temp;
    }
    
    else
    {
        head -> prev = temp;
        temp -> next = head;
        head = temp;
    }
    _size++;
}
// Adds a new integer to the back of the list
void DEList:: push_back(int new_val)
{
    DEItem* temp = new DEItem;
    temp->val = new_val;
    temp->next = NULL;
    temp->prev = tail;
    
    if(empty())
    {
        head = temp;
        tail = temp;
    }
    
    else
    {
        tail -> next = temp;
        temp -> prev = tail;
        tail = temp;
    }
    _size++;
}
// Removes the front item of the list (if it exists)
void DEList:: pop_front()
{
    if(!empty())
    {
        //make a copy of head b/c trying to remove it
        DEItem* temp = head;
        //advance head to the next item so we can pop the one before
        //by calling head later on!
        head = head -> next;
        
        //this can only happen if the list is greater than 1
        if(size()>1)
        {
            head->prev = NULL;
        }
        else
        {
            //why tail?
            tail = NULL;
        }
        _size--;
        delete temp;
    }    
}
// Removes the back item of the list (if it exists)
void DEList:: pop_back()
{
    if(!empty())
    {
        DEItem* temp = tail;
        tail = tail -> prev;
        
        if(size()>1)
        {
            tail->next = NULL;
        }
        else
        {
            //would we set head to NULL here?
            head = NULL;
        }
        _size--;
        delete temp;
    }
}