#include "web.h"

Web::Web() 
{
   // constructor

}

Web::~Web() 
{ 
    // destructor 
}

/*
     reads in and parse graph from a file.
     @filename: is the name of the file describing the webgraph.
     @return: true in success , and false in failure.
 */
bool Web::read_graph(const char *filename) 
{
    //initialize string stream
    stringstream ss;

    ifstream ifile;
    //check if file can open
    ifile.open(filename);
    
    if(ifile.fail())
    {
        return false;
    }
    
    //now check the size
	int tempNumpages=0;
    ifile >> tempNumpages;
    
    if(ifile.fail())
    {
        return false;
    }
    
    //creates the # of pages in web class
    n = tempNumpages;
    
    
    //loops while graph is read line by line
    //now putting info onto the pages
    for(int i=0; i<n; i++)
    {
        int id = 0;
        string url = "";
        double rank = 0.0;
        
        //temp value for links sent thru ss
        int holdTemp=0;
        
        vector<int> temp;
        
        //get id, url, & rank
        ifile >> id >> url >> rank;
        
        string line;
        //getline for the extra enter
        getline(ifile, line);
        
        //read in line of links
        getline(ifile, line);
        
        //line goes into stringstream
        ss << line;

        //put ss into temp var 
        while(ss >> holdTemp)
        {
            //page is added to vector
            temp.push_back(holdTemp);
        }
        //create new Page for objects from input
        Page new_page(id, url, rank, temp);
        
        pageList.push_back(new_page);
        //so ss can be cleared and used again
        ss.clear();
    }
    //close file once finished
    ifile.close();
    return true;
}
/*
     writes out webgraph to a file.
     @filename: is the name of the file to write to.
     @return: true in success , and false in failure
    */
 
bool Web::write_graph(const char *filename)
{
    //initialize for new file 
    int _id;
    double _rank;
    string _url;
    vector <int> _links;
    
    //writing into new file
    ofstream ofile;
    
    //check if file opens
    ofile.open(filename);
    if(ofile.fail())
    {
        return false;
    }
    
    int numP = pageList.size();
    //read to file
    ofile << numP << endl;
    
    /*loop through num web pages to read
    to new file */
    for(int x=0; x<numP; x++)
    { 
        /* writes values into new
        file model */
        _id = pageList[x].get_id();
        ofile << _id << endl;
        _url = pageList[x].get_url();
        _rank = pageList[x].get_rank();
        
        // this ends with "\t"
        ofile << "\t" << _url << endl;
        ofile << "\t" << _rank << endl;
        
        ofile << "\t";
        _links = pageList[x].get_vector();
        int _linkSize = (int)_links.size();
        
        //prints each link line by line
        for(int y=0; y<_linkSize; y++)
        {
            ofile << _links[y] << " ";
        }
        ofile << endl;
	}
    
    
    ofile.close();
    return true;
}
 /*
     calculates the rank of the pages
     @S: is the number of simulation iteration.
     @N: is the number of surfer
*/
void Web::calculate_rank(int S,int N)
{
    int leftOver = 0;
    int perPage = 0;
    
    //surfers mod by # webpages for leftover
    leftOver = N % n;
    //surfers div by # webpages to spread evenly
    perPage = N/n;
    
    
    //create walker vec
    vector<int>walker;
    //temp walker 
    vector<int>walkerTemp(n, 0);
    
    //distribute walkers across pages
    for(int i=0; i<perPage; i++)
    {
        //on one page
        for(int j=0; j<n; j++)
        {
            walker.push_back(pageList[j].get_id());;
        }
    }
    
    for(int i=0; i<leftOver; i++)
    {
        walker.push_back(pageList[i].get_id());
    }  
      
    //loops through each simulation
    //walkers are moving!
    for(int i=0; i<S; i++)
    {
        //through all pages
        for(int j=0; j<N; j++)
        {
            //create vector class to get num of links
            vector<int> linkTemp = pageList[walker[j]].get_vector();

            //take size of temporary link vec for numlinks
            int linkNum = linkTemp.size();

            if(linkNum!=0)
            {
                int randVal = rand()%(linkNum);
                int r = linkTemp[randVal];
                walker[j] = r;

            }                
        }
    }
    
    //modulate page count
    for(int i=0; i<N; i++)
    {
        walkerTemp[walker[i]]++;
    }    
        
    //set page rank using walker size as pageNum
    for(int i=0; i<n; i++)
    {
        pageList[i].set_rank((double)walkerTemp[i]/(double)(N));
    }
                                   
}
