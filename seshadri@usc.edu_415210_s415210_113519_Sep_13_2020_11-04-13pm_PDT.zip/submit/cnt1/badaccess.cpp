#include <iostream>
#include "bigint.h"

using namespace std;

int main()
{
        BigInt fav("5555");
        BigInt hee("1000");
        fav.add(hee);
        cout << fav.getNumber()[1] << endl; 
        return 0;
}