/*******************************************************************************
 * CS 103 Twenty-One (Blackjack) PA
 * Name: Eshana Seshadri
 * USC email: seshadri@usc.edu
 * Comments (you want us to know):
 * Blackjack game 1v1.
 *
 ******************************************************************************/

// Add other #includes if you need
#include <iostream>
#include <cstdlib>

using namespace std;

/* Prototypes */
void shuffle(int cards[]);
void printCard(int id);
int cardValue(int id);
void printHand(int hand[], int numCards);
int getBestScore(int hand[], int numCards);

const int NUM_CARDS = 52;

/**
 * Global arrays to be used as look-up tables, if desired.
 * It is up to you if and how you want to use these 
 */
const char suit[4] = {'H','S','D','C'};
const char* type[13] = 
  {"2","3","4","5","6","7",
   "8","9","10","J","Q","K","A"};
const int value[13] = {2,3,4,5,6,7,8,9,10,10,10,10,11};

/**
 * Should permute the deck of cards, effectively shuffling it.
 * You must use the Fisher-Yates / Durstenfeld shuffle algorithm
 *  described in the assignment writeup.
 */
void shuffle(int cards[])
{
  /******** You complete ****************/
    for(int i=NUM_CARDS-1 ; i>=1; i--)
    {
        int j = rand() % (i+1);
        int temp = cards[j];
        cards[j] = cards[i];
        cards[i] = temp;
    }
}

/**
 * Prints the card in a "pretty" format:   "type-suit"
 *  Examples:  K-C  (King of clubs), 2-H (2 of hearts)
 *  Valid Types are: 2,3,4,5,6,7,8,9,10,J,Q,K,A
 *  Valid Suits are: H, D, C, S
 */
void printCard(int id)
{
  /******** You complete ****************/
    cout << type[id%13] << "-" << suit[id/13] << " "; 
}

/**
 * Returns the numeric value of the card.
 *  Should return 11 for an ACE and can then
 *  be adjusted externally based on the sum of the score.
 */
int cardValue(int id)
{
  /******** You complete ****************/
    return value[id%13];
}

/**
 * Should print out each card in the hand separated by a space and
 * then print a newline at the end.  
 * Should use printCard() to print out each card.
 */
void printHand(int hand[], int numCards)
{
  /******** You complete ****************/
    // how do i input everything into the hands array?
    // doesn't the cards[] array die within the other function?? 
    for(int i=0; i<numCards; i++)
    {
       printCard(hand[i]); 
    }
    cout << " " << endl;
}

/**
 * Should return the total score of the provided hand.  
 * ACES should be treated as 11s to make the highest possible hand
 *  and only being reduced to 1s as needed to avoid busting.
 */
int getBestScore(int hand[], int numCards)
{
  /******** You complete ****************/
    
    //calculates total, taking into account total aces
    int total = 0;
    int aceTotal = 0;    
    for(int i=0; i<numCards; i++)
    {
       if(cardValue(hand[i]) == 11)
       {
           aceTotal++;
       }
        
       total+= cardValue(hand[i]);       
    }
    //goes through all cards in hand array to convert ace to 1 
    //based on total
    for(int a=0; a<aceTotal; a++)
    {
       if(total>21)
       {
           total-=10;
       }
       else
       {
           break; 
       }
    }
    return total;
}


/**
 * Main program logic for the game of 21
 */
int main(int argc, char* argv[])
{
  //---------------------------------------
  // Do not change this code -- Begin
  //---------------------------------------
  if(argc < 2){
    cout << "Error - Please provide the seed value." << endl;
    return 1;
  }
  int seed = atoi(argv[1]);
  srand(seed);

  int cards[52];
  int dhand[9];
  int phand[9];
  //---------------------------------------
  // Do not change this code -- End
  //---------------------------------------

  /******** You complete ****************/
    char playOn = ' ';
    char playNextGame;
    bool again = true;
    const int BJACKMAX = 21;
    
    //loop continues while player wants to play again
    while(again == true){
        
        for(int i=0; i<52; i++)
        {
          cards[i] = i;  
        }
        
        int bestScoreP = 0;
        int bestScoreD = 0;
        int countDeck = 0;
        int pCount = 0;
        int dCount = 0;
        
        shuffle(cards);
        
        //first two cards for each player are dealt
        phand[0] = cards[0];
        dhand[0] = cards[1];
        
        phand[1] = cards[2];
        dhand[1] = cards[3];
        
        pCount = 2;
        dCount = 2;
        countDeck = 4;
                
        cout << "Dealer: ? ";   
        printCard(dhand[1]);
        cout << endl;
        
        cout << "Player: ";
        printHand(phand,pCount);
       
        // re-intializes best scores
        bestScoreP = getBestScore(phand,pCount);
        bestScoreD = getBestScore(dhand,dCount);
        

        /* loop continues while player continues to hit
        and score is less than 21. If either is not met, it breaks*/
        while(bestScoreP < BJACKMAX)
        {
            cout << "Type 'h' to hit and 's' to stay:" << endl;
            cin >> playOn;

            if (playOn != 'h')
            {
                break;
            }
            
            phand[pCount++] = cards[countDeck++];
            
            cout << "Player: ";
            printHand(phand,pCount); 
            bestScoreP = getBestScore(phand,pCount);
            
            // if new best score is larger than 21, player busts immediately
            if(bestScoreP > BJACKMAX)
            {
                cout << "Player busts" << endl;
                cout << "Lose " << bestScoreP;
                cout << " " << bestScoreD << endl;
                break;
            }   
        }
        
        /* If player's best score is greater than 21 at first attempt
        (player does not enter first loop) */
        if((playOn != 'h') && (bestScoreP > BJACKMAX))
        {
            
            cout << "Player: ";
            printHand(phand,pCount); 
            cout << "Player busts" << endl;
            cout << "Lose " << bestScoreP;
            cout << " " << bestScoreD << endl;
            
        }
        else if(bestScoreP <= BJACKMAX)
        {
            while(bestScoreD < 17)
            {
                dhand[dCount++] = cards[countDeck++];
                bestScoreD = getBestScore(dhand, dCount);
                
            }         
        }
        
        // if player does not hit and scores are tied
        if((playOn != 'h') && (bestScoreP==bestScoreD))
        {
            cout << "Dealer: ";
            printHand(dhand, dCount);
            cout << "Tie " << bestScoreP << " ";
            cout << bestScoreD << endl;
     
        }
        //else : calculating scores for dealer
        else
        {

            if(bestScoreD > BJACKMAX)
            {
                cout << "Dealer: ";
                printHand(dhand, dCount);
                cout << "Dealer busts" << endl;
                cout << "Win " << bestScoreP << " ";
                cout << bestScoreD << endl;              
                            
            }
            //Dealer has a higher score and did not bust
            else if((bestScoreD > bestScoreP) && (bestScoreD<=BJACKMAX))
            {
                    cout << "Dealer: ";
                    printHand(dhand, dCount);
                    cout << "Lose " << bestScoreP << " ";
                    cout << bestScoreD << endl;

            }
            //Player has a higher score and did not bust
            else if((bestScoreP > bestScoreD) && (bestScoreP<=BJACKMAX))
            {
                    cout << "Dealer: ";
                    printHand(dhand, dCount);
                    cout << "Win " << bestScoreP << " ";
                    cout << bestScoreD << endl;

            }
        }
        /*'Play again?' is asked outside of all statements but
         within the while loop */
        cout << "Play again? [y/n]" << endl;
        cin >> playNextGame;

        if(playNextGame == 'y')
        {
            again = true; 
        }
        else
        {
            again = false;
            return 0;
        }
        
    }
    
    return 0;
}
    
 
    
 
