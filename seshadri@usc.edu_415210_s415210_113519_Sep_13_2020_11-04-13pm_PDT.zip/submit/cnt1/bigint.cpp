#include "bigint.h"
#include <iostream>
#include <cmath>

using namespace std;

//converts digits (characters of s) to ints (elements of vector)
//reversing the order

//convert string --> Big Int
//reverses
BigInt::BigInt(string s)
{
    length = (int)s.length() - 1;
    
    for(int i=length; i>=0; i--)
    {
        digit = ((int)s[i]) - 48;
        number.push_back(digit);
    }
}
    
//get string representation
string BigInt::to_string()
{
    size = (int)number.size() - 1;
    // 0, but since it's character it's a space
    string_number = "";
    
    for(int i=size; i>=0; i--)
    {
        string_number += (char)(number[i] + 48);
    }
    
    return string_number;
}

//add another BigInt to this
void BigInt::add(BigInt b)
{
    sum = 0;
    carry_on = 0;
    
    if(number.size() != b.number.size())
    {
        while(number.size() != b.number.size())
        {
            if(number.size() > b.number.size())
            {
                b.number.push_back(0);
            }
            else
            {
                number.push_back(0);
            }
        }
    }
    
    for(int i=0; i<number.size(); i++)
    {
        sum = number[i] + b.number[i] + carry_on;
        carry_on = 0;
        carry_on = sum/10;
        number[i] = (sum%10);
    }
    
    if(carry_on>0)
    {
        number.push_back(carry_on);
    }
              
}
        
           
    
    
    
