/* Author: Eshana Seshadri
 * Program: prime23
 * Description: Determines if a natural number (greater than 1) has only 2 and/or 3 as prime factors (but no other prime factors) and how many of each factor (2 and 3) does it have.
 */
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main()
{
    int n = 0;
    int numTwos = 0;
    int numThrees = 0;
    cout << "Enter a positive integer: " << endl;
    cin >> n;
    
   
    while((n%2==0) || (n%3==0))
    {
        if(n%2==0)
        {
            numTwos++;
            n = n/2;
        }
        else if(n%3==0)
        {
            numThrees++;
            n = n/3;
        }

    }
    if(n==1)
    {
        cout << "Yes" << endl;
        cout << "Twos=" << numTwos << " " << "Threes=" << numThrees << endl;
    }
    else
    {
        cout << "No" << endl;
    }
}
        