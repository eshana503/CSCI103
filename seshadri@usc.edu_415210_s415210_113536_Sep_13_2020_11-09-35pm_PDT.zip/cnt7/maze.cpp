/* 
maze.cpp

Author: Eshana Seshadri

Short description of this file:
*/

#include <iostream>
#include "mazeio.h"
//need to be able to access Location struct, etc.
#include "queue.h"

using namespace std;

// Prototype for maze_search, which you will fill in below.
int maze_search(char**, int, int);

// main function to read, solve maze, and print result
int main(int argc, char* argv[]) {
   int rows, cols, result;
   char** mymaze=NULL;
   
   if(argc < 2)
   {
       cout << "Please provide a maze input file" << endl;
       return 1;
   }
   mymaze = read_maze(argv[1], &rows, &cols);
   
   if (mymaze == NULL) {
      cout << "Error, input format incorrect" << endl;
      return 1;
   }

   // when working on Checkpoint 3, you will call maze_search here.
   // here. but for Checkpoint 1, just assume we found the path.
   result = maze_search(mymaze, rows, cols); // TO BE CHANGED

   // examine value returned by maze_search and print appropriate output
   if (result == 1) { // path found!
      print_maze(mymaze, rows, cols);
   }
   else if (result == 0) { // no path :(
      cout << "No path could be found!" << endl;
   }
   else { // result == -1
      cout << "Invalid maze." << endl;
   }

   // to delete all memory reallocated 
       for(int i=0; i<rows; i++)
       {
           delete[] mymaze[i];
       }

       delete[] mymaze;
       mymaze = NULL;
   
   return 0;
}

/**************************************************
 * Attempt to find shortest path and return:
 *  1 if successful
 *  0 if no path exists
 * -1 if invalid maze (not exactly one S and one F)
 *
 * If path is found fill it in with '*' characters
 *  but don't overwrite the 'S' and 'F' cells
 *************************************************/
int maze_search(char** maze, int rows, int cols) 
{
    //make sure the startpt & endpt exist
    //if not --> invalid maze
    int startPoint=0;
    int endPoint=0;
    
    //set Location start
    Location starting;
    
    //keeps count of startpt
    for(int i=0; i<rows; i++)
    {
        for(int j=0; j<cols; j++)
        {
            if(maze[i][j] == 'S')
            {
                startPoint++;
                //initialize starting location
                starting.row = i;
                starting.col = j;
            }
        }
    }
    
    //keeps count of endpt
     for(int i=0; i<rows; i++)
    {
        for(int j=0; j<cols; j++)
        {
            if(maze[i][j] == 'F')
            {
                endPoint++;
            }
        }
     }
    
    //return -1 if there is not
    //1 of each end & startpt
    
    if(endPoint !=1 || startPoint!=1 )
    {
        return -1;
    }
    
    //Make a queue initialized to max size
    Queue list(rows*cols);
    
    //Create predecessor grid
    //initialize Locations    
    Location** predecessor = new Location* [rows];
    
    Location preL;
    preL.row = -1;
    preL.col = -1;
    
    for(int i=0; i<rows; i++)    
    {
        predecessor[i] = new Location[cols];
        for(int j=0; j<cols; j++)
        {
            predecessor[i][j] = preL;            
        }
    }
    
    //Create visited grid
    //initialize to zero
    int** visited = new int* [rows];
        
    for(int i=0; i<rows; i++)
    {
        visited[i] = new int[cols];
        for(int j=0; j<cols; j++)
        {
            visited[i][j] = 0;            
        }
    }    
    
    //Add starting location to back of queue
    //declare curr location for that array
    list.add_to_back(starting);
    Location curr;

    //declare direction locations
    Location north;
    Location south;
    Location east;
    Location west;
    
    //Now enter a loop while queue is not empty
    while(!list.is_empty())
    {
        curr = list.remove_from_front();
        
        //go north
        //stay inside the maze boundaries
        north.row = curr.row-1;
        north.col = curr.col;
        
        if(north.row>=0 && north.row<rows && north.col>=0
           && north.col<cols)
        {
            if(maze[curr.row-1][curr.col]=='F')
            {
                while(maze[curr.row][curr.col] != 'S')
                {
                    maze[curr.row][curr.col] = '*';
                    curr = predecessor[curr.row][curr.col];
                }
                /*since finish has been found
                memory can be deallocated in 
                predecessor & visited arrays */
                for(int i=0; i<rows; i++)
                {
                    delete[] predecessor[i];
                    delete[] visited[i];
                }
                delete[] predecessor;
                delete[] visited;
                
                return 1;

            }
            else if(maze[curr.row-1][curr.col]=='#')
            {
            }
            else if(maze[curr.row-1][curr.col]=='.'
                    && visited[curr.row-1][curr.col]==0)
            {
                visited[curr.row-1][curr.col]=1;
                predecessor[curr.row-1][curr.col]=curr;
                list.add_to_back(north);                
            }
            
        }
        
        
        //go south
        //stay inside the maze boundaries
        south.row = curr.row+1;
        south.col = curr.col;
        
        if(south.row>=0 && south.row<rows && south.col>=0
           && south.col<cols)
        {
            if(maze[curr.row+1][curr.col]=='F')
            { 
                while(maze[curr.row][curr.col] != 'S')
            {
                maze[curr.row][curr.col] = '*';
                curr = predecessor[curr.row][curr.col];
            }
                /*since finish has been found
                memory can be deallocated in 
                predecessor & visited arrays */
                for(int i=0; i<rows; i++)
                {
                    delete[] predecessor[i];
                    delete[] visited[i];
                }
                delete[] predecessor;
                delete[] visited;
                
                return 1;

            }
            else if(maze[curr.row+1][curr.col]=='#')
            {
            }
            else if(maze[curr.row+1][curr.col]=='.'
                    && visited[curr.row+1][curr.col]==0)
            {
                visited[curr.row+1][curr.col]=1;
                predecessor[curr.row+1][curr.col]=curr;
                list.add_to_back(south);
                
            }
        }
        
        
        //go east
        //stay inside the maze boundaries
        east.row = curr.row;
        east.col = curr.col+1;
        
        if(east.row>=0 && east.row<rows && east.col>=0
           && east.col<cols)
        {
            if(maze[curr.row][curr.col+1]=='F')
            {
                while(maze[curr.row][curr.col] != 'S')
                {
                    maze[curr.row][curr.col] = '*';
                    curr = predecessor[curr.row][curr.col];
                }
                /*since finish has been found
                memory can be deallocated in 
                predecessor & visited arrays */
                for(int i=0; i<rows; i++)
                {
                    delete[] predecessor[i];
                    delete[] visited[i];
                }
                delete[] predecessor;
                delete[] visited;
                
                return 1;

            }
            else if(maze[curr.row][curr.col+1]=='#')
            {
            }
            else if(maze[curr.row][curr.col+1]=='.'
                    && visited[curr.row][curr.col+1]==0)
            {
                visited[curr.row][curr.col+1]=1;
                predecessor[curr.row][curr.col+1]=curr;
                list.add_to_back(east);
                 
            }
        }
             
        //go west
        //stay inside the maze boundaries
        west.row = curr.row;
        west.col = curr.col-1;
        
        if(west.row>=0 && west.row<rows && west.col>=0
           && west.col<cols)
        {
            if(maze[curr.row][curr.col-1]=='F')
            {
                while(maze[curr.row][curr.col] != 'S')
            {
                maze[curr.row][curr.col] = '*';
                curr = predecessor[curr.row][curr.col];
            }
                /*since finish has been found
                memory can be deallocated in 
                predecessor & visited arrays */
                for(int i=0; i<rows; i++)
                {
                    delete[] predecessor[i];
                    delete[] visited[i];
                }
                delete[] predecessor;
                delete[] visited;
                
                return 1;

            }
            else if(maze[curr.row][curr.col-1]=='#')
            {
            }
            else if(maze[curr.row][curr.col-1]=='.'
                    && visited[curr.row][curr.col-1]==0)
            {
                visited[curr.row][curr.col-1]=1;
                predecessor[curr.row][curr.col-1]=curr;
                list.add_to_back(west);
                
            }
        }
    }  
    
    //return false
    return 0; 
    
}
